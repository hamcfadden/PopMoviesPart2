package com.udacity.heather.popmoviesstage1final.Models;

import java.util.List;


public class Reviews {
    private List<ReviewItem> results = null;

    public List<ReviewItem> getResults() {
        return results;
    }
}

