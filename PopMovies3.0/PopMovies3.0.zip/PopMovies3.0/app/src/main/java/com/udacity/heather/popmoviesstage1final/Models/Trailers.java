package com.udacity.heather.popmoviesstage1final.Models;

import java.util.List;

public class Trailers {
    private List<TrailerItem> results = null;

    public List<TrailerItem> getResults() {
        return results;
    }
}
